import { useEffect, useState } from "react";
import AggiornaContatto from "./AggiornaContatto";

const ListaContatti = () => {
  const [risCanc, setRisCanc] = useState(false);

  const [risUpdate, setRisUpdate] = useState(false);
  const [contatto, setContatto] = useState({});

  const [contatti, setContatti] = useState([]);
  const [conttattiUnici, setContattiUnici] = useState([]);


  useEffect(() => {
    const getContatti = async () => {
      const res = await fetch("http://localhost:3030/listaContatti");

      const data = await res.json();
      console.log(data);
      setContatti(data);
      setContattiUnici([...new Map(data.map(item => [item["idContatto"], item])).values()])

    };
    getContatti();
  }, []);


  const eliminaContatto = async (nome, cognome, id) => {
    if (window.confirm(`Vuoi davvero eliminare ${nome} ${cognome}`)) {

      const res = await fetch("http://localhost:3030/eliminaContatto", {
        method: "DELETE",
        headers: {
          "Content-type": "application/json"
        },
        body: JSON.stringify({ id })
      });

      const { status } = await res.json();
      setRisCanc(status);
    }
  }


  if (risCanc) return (
    <div>
      <h1>Contatto eliminato!</h1>
    </div>
  )
  if (risUpdate) return <AggiornaContatto contatto={contatto} contatti={contatti} />

  if (contatti)
    return (

      <table>
        <thead>
          <tr>
            <th>Nome</th>
            <th>Cognome</th>
          </tr>
        </thead>

        {conttattiUnici.map((e, index) => {
          return (
            <tbody key={index}>
              <tr>
                <td>{e.Nome}</td>
                <td>{e.Cognome}</td>
                <td><button onClick={() => eliminaContatto(e.Nome, e.Cognome, e.idContatto)}>ELIMINA</button></td>
                <td><button onClick={() => { setRisUpdate(true); setContatto(e) }}>AGGIORNA</button></td>
              </tr>
            </tbody>
          );
        })}
      </table >
    );
  return (
    <div>
      <h1>Nessun contatto...</h1>
    </div>
  );
};

export default ListaContatti;
