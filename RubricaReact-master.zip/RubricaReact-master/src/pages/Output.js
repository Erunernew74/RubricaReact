import React from 'react'

const Output = ({ data }) => {
    return (
        <div>
            <h1>{data.msg}</h1>
        </div>
    )
}

export default Output
