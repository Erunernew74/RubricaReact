import React from 'react'

const FormInput = ({id}) => {
    return (
        <>
            <input type="text" id={id}  placeholder="Numero..." />
        </>
    )
}

export default FormInput
